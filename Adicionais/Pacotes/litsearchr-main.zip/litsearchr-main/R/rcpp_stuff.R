#' @useDynLib
#' @importFromRcpp sourceCpp
